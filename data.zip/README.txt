
Comparative Siouan Dictionary data dump
=======================================

Data of Comparative Siouan Dictionary is published under the following license:
http://creativecommons.org/licenses/by/4.0/

It should be cited as

Rankin, Robert L. & Carter, Richard T. & Jones, A. Wesley & Koontz, John E. & Rood, David S. & Hartmann, Iren (eds.) 2015.
Comparative Siouan Dictionary.
Leipzig: Max Planck Institute for Evolutionary Anthropology.
(Available online at http://csd.clld.org, Accessed on 2015-07-07.)


This package contains files in csv format [1] with corresponding schema descriptions in
JSON table schema [2] format, representing rows in database tables of the Comparative Siouan Dictionary web
application [3,4].

[1] http://csvlint.io/about
[2] http://dataprotocols.org/json-table-schema/
[3] http://csd.clld.org
[4] https://github.com/clld/csd
